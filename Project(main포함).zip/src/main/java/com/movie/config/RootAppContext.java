package com.movie.config;

import org.springframework.context.annotation.Configuration;


//root-context.xml대신 작성
@Configuration
public class RootAppContext {

}
